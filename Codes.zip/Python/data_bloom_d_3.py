import os
import random
import pandas as pd
import tensorflow as tf
import numpy as np
from keras.layers import Input, Dense, Lambda, Reshape, Dot
import keras
from keras.optimizers import Adam
from keras.models import Model
from ann_visualizer.visualize import ann_viz
import matplotlib.pyplot as plt
from scipy.linalg import expm

#Set seed for reproducibility
seed_value = 50
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

# Set the PYTHONHASHSEED environment variable for further consistency
os.environ['PYTHONHASHSEED'] = str(seed_value)

# Set default figure size globally
plt.rcParams['figure.figsize'] = [10, 6]


#I first try with a small dataset

start_date = "2017-01-01"
end_date = "2017-12-31"


df_zcb_og = pd.read_csv("C:\\Users\\giaco\\Desktop\\tesi\\data bloomberg\\price_all_05.csv")
df_zcb_19_23 = df_zcb_og[(df_zcb_og['Dates'] >= start_date) & (df_zcb_og['Dates'] <= end_date)]
df_zcb = df_zcb_19_23.drop(columns="Dates")


ttm_zcb_og = pd.read_csv("C:\\Users\\giaco\\Desktop\\tesi\\data bloomberg\\ttm_all_05.csv")
ttm_zcb_19_23 = ttm_zcb_og[(ttm_zcb_og['Dates'] >= start_date) & (ttm_zcb_og['Dates'] <= end_date)]
ttm_zcb = ttm_zcb_19_23.drop(columns="Dates")


ttm_zcb_sort = ttm_zcb.apply(lambda row: pd.Series(sorted(row)), axis=1)


# Calculate the sorting indices for each row in ttm_zcb
sort_indices = ttm_zcb.apply(np.argsort, axis=1)

# Use the indices to sort df_zcb in the same way
df_zcb_sorted = pd.DataFrame([df_zcb.iloc[i].values[indices] for i, indices in enumerate(sort_indices.values)], index=df_zcb.index)

t_bill_prices_np = df_zcb_sorted.to_numpy()
t_bill_prices_ts_list = [tf.constant(t_bill_prices_np[:, i:i+1], dtype=tf.float32) for i in range(t_bill_prices_np.shape[1])] # create a list
real_p_target = tf.convert_to_tensor(t_bill_prices_ts_list) # convert to tensor data


t_bill_tenors = ttm_zcb_sort.astype(float)
t_bill_tenors = t_bill_tenors.to_numpy()
tenors = tf.convert_to_tensor(t_bill_tenors) # convert to tensor data


#### Parameters
n = 3  # dimension for Z
M = t_bill_tenors.shape[1]   #number of bonds
N = t_bill_tenors.shape[0]  ## Number of observation dates
## Adding constant dimension count
n = n + 1  # dimension matrix



def build_scalar_model(n):  # only for 1 price relative to one maturity

        # define the inputs of the model
        x_in = Input(shape=(1,), name='tenor')
        z_in = Input(shape=(n,), name='state factor')

        # build x*A, i.e. input x times a 1 times n^2 matrix
        # dense layer hyperparameters (no activation specified and no bias)
        n_neurons = n ** 2
        A_vec = Dense(units=n_neurons, use_bias=False)(x_in)
        # reorder the matrix x*A to an n times n matrix
        A = Reshape((n, n))(A_vec)
        # Calculate the matrix exponential exp(x*A)
        # Lambda wraps functions as keras layers
        exp_xA = Lambda(lambda x: tf.linalg.expm(x))(A)

        # obtain first row e_0*expm(x*A) of the matrix exponential exp(x*A)
        # Note: first dimension are for parallel computations and, we want them all
        # Second dimension are for the rows of the resulted matrix
        # Third dimension are for the columns of the resulted matrix

        e_exp_xA = exp_xA[:, 0, :]  # pick first row
        # obtain scalar product (e_0*expm(x*A))*z of the first row e_0*expm(x*A) with z)
        p = Dot(axes=1)([e_exp_xA, z_in])
        # Build the model p = e_0*expm(x*A)*z
        return Model(inputs=[x_in, z_in], outputs=p)  # it groups all the layers and define the model


# Build the model
pricemodel = build_scalar_model(n)



# Vector model

def build_vectormodel(pricemodel):
    x_in = Input(shape=(M,), name='tenor')
    z_in = Input(shape=(n,), name='state factor')
    p = []   #list of prices
    for i in range(M):
        p = p + [pricemodel([x_in[:, i], z_in])]  # all the values of x in that column, all rows but only one column at time
    return(Model(inputs = [x_in, z_in], outputs = p))


pricevec = build_vectormodel(pricemodel)
pricevec.summary()


#training

x_train = tenors
z_trainable = tf.Variable(tf.ones((N, n)))
# Combine x and z as input to the model
input_data = [x_train, z_trainable]  # create a list of two tensor arrays (the tenors and z)


# loss function
def loss_function(y_true, y_pred):
    return tf.keras.losses.mean_squared_error(y_true, y_pred)


# optimizer
optimizer = Adam(learning_rate=0.01)



# Use TensorFlow GradientTape to compute gradients
def compute_gradients(input_vars):
    x, z = input_vars
    with tf.GradientTape() as tape:
        p_pred = pricevec([x, z])
        loss = loss_function(real_p_target, p_pred)
    gradients = tape.gradient(loss, pricevec.trainable_variables + [z])
    return gradients



# Function for training loop using gradient descent
def update_z_weights(epochs=100,silent=True):
    br_step = 10
    br = br_step
    for epoch in range(epochs):
        if silent == False:
            print(epoch,"/",epochs,"...",end="")
        if epoch >= br:
            br = br+br_step
            print("")
        gradients = compute_gradients([x_train, z_trainable])
        optimizer.apply_gradients(zip(gradients, pricevec.trainable_variables + [z_trainable]))
        # Update only the model's trainable variables
        z_trainable.assign(tf.concat([tf.ones((N, 1)), z_trainable[:,1:]], axis=1))


def train(epochs=50,maxLoss = 0.001,tries=10,verbose=1):
## Improve weights in case of bad loss
    silent = True
    if verbose == 1:
        silent = False
    if verbose != 0:
        print("Attempting to reach a loss of at most",maxLoss,"with",epochs,"(adaptive) gradient descent steps.\nIf loss is not reached. Repeat up to",tries,"times.")
    loss_vec = []
    for k in range(tries):
        Loss = np.mean(loss_function(real_p_target, pricevec([x_train, z_trainable]))) ## MSE
        loss_vec.append(Loss)
        if verbose != 0:
            print("(MSE) Loss after",k,"attempt(s):",Loss,"\n")
        if Loss > maxLoss:
            if verbose != 0:
                print("Updating parameters with another",epochs,"gradient descent steps!")
            update_z_weights(epochs,silent)
            if Loss <= maxLoss:
                break;
                ## Obtain the optimized values
    optimized_weights = [var.numpy() for var in pricemodel.trainable_variables]
    optimized_z = z_trainable.numpy()
    return optimized_weights, optimized_z, loss_vec


## Start parameter optimisation
optimized_weights, optimized_z, mse= train(epochs=8,maxLoss=0.00000001,tries=60, verbose=1)




dates = pd.date_range(start=start_date, end=end_date, periods=optimized_z.shape[0])


def opt_z_fun(optimized_z, dates):
    # Calculate pairwise correlation coefficients
    corr_Z1_Z2 = np.corrcoef(optimized_z[:, 1], optimized_z[:, 2])[0, 1]
    corr_Z1_Z3 = np.corrcoef(optimized_z[:, 1], optimized_z[:, 3])[0, 1]
    corr_Z2_Z3 = np.corrcoef(optimized_z[:, 2], optimized_z[:, 3])[0, 1]

    # Print the pairwise correlations
    print("\nPairwise Correlations:")
    print(f"Correlation between $Z_1$ and $Z_2$: {corr_Z1_Z2:.4f}")
    print(f"Correlation between $Z_1$ and $Z_3$: {corr_Z1_Z3:.4f}")
    print(f"Correlation between $Z_2$ and $Z_3$: {corr_Z2_Z3:.4f}")

    # Plotting time series for Z1, Z2, and Z3 together
    plt.figure(figsize=(10, 6))
    plt.plot(dates, optimized_z[:, 1], linestyle='-', color='b', label='$Z_1$')
    plt.plot(dates, optimized_z[:, 2], linestyle='-', color='r', label='$Z_2$')
    plt.plot(dates, optimized_z[:, 3], linestyle='-', color='g', label='$Z_3$')
    plt.xlabel('Time')
    plt.ylabel('Values')
    plt.legend()
    plt.grid(True)

    # Add text for pairwise correlations inside the plot
    plt.text(dates[int(len(dates) * 0.04)],  # Adjusted position to move text right
             max(optimized_z[:, 1]) * 0.988,
             f'Correlation $Z_1$ and $Z_2$: {corr_Z1_Z2:.4f}\n'
             f'Correlation $Z_1$ and $Z_3$: {corr_Z1_Z3:.4f}\n'
             f'Correlation $Z_2$ and $Z_3$: {corr_Z2_Z3:.4f}',
             fontsize=12,
             bbox=dict(facecolor='white', alpha=0.5))

    plt.tight_layout()
    plt.show()

    # Scatter plot for Z1 and Z2
    plt.figure(figsize=(6, 6))
    plt.scatter(optimized_z[:, 1], optimized_z[:, 2], alpha=0.5)
    plt.xlabel('$Z_1$')
    plt.ylabel('$Z_2$')
    plt.title('Scatter plot of $Z_1$ vs $Z_2$')
    plt.grid(True)

    # Add text for the correlation value inside the scatter plot
    plt.text(min(optimized_z[:, 1]) + 0.01 * (max(optimized_z[:, 1]) - min(optimized_z[:, 1])),
             max(optimized_z[:, 2]) - 0.01 * (max(optimized_z[:, 2]) - min(optimized_z[:, 2])),
             f'Correlation: {corr_Z1_Z2:.4f}',
             fontsize=12,
             bbox=dict(facecolor='white', alpha=0.5))

    plt.tight_layout()
    plt.show()

opt_z_fun(optimized_z, dates)


def errror_plot():
    p_target_s = np.squeeze(real_p_target)
    p_pred_list = pricevec([x_train, optimized_z])
    p_pred = np.transpose(np.column_stack(p_pred_list))
    ## deviation is the vector of actual price errors
    deviation = p_pred - p_target_s
    ## err is the mean square error
    err = np.mean((deviation) ** 2)
    print("\n\nRMSE error:", np.sqrt(err), "\n")
    return np.sqrt(err), pd.DataFrame(p_pred)


RMSE, prices_est = errror_plot()




def base_weight(tenors, optimized_weights, df_zcb_sorted,  optimized_z, pred_pd,n):
    tenors_last = tenors[tenors.shape[0] - 1, :].numpy().tolist()  # list of 47 numbers
    A = np.array(optimized_weights).reshape(n, n)  # ndarray 2x2
    # last_Z = optimized_z[-1, 1]
    prices_plot = pred_pd.iloc[-1]
    real_price = df_zcb_sorted.iloc[-1]

    exp_matrices_list = []

    for ttm_loop in tenors_last:
        exp_matrix = expm(A * ttm_loop)
        exp_matrices_list.append(exp_matrix)

    basis_vec = np.zeros((1, n))
    basis_vec[0, 0] = 1

    first_rows_list = []

    # Extract the first row of each matrix exponential
    for exp_matrix_loop in exp_matrices_list:
        result = np.dot(basis_vec, exp_matrix_loop)
        first_rows_list.append(result)

        # Initialize lists for entries
    entries_lists = [[] for _ in range(n)]

    # Extract entries and multiply by corresponding Z values
    for row in first_rows_list:
        for i in range(n):
            if i == 0:
                entries_lists[i].append(row[0, i])
            else:
                # if i < optimized_z.shape[1]:  # Ensure there's a corresponding Z value
                entries_lists[i].append(row[0, i])

    # Plotting the results
    def plot_base_weight():
        plt.figure(figsize=(10, 6))

        plt.plot(tenors_last, entries_lists[0], label='Base Curve', marker='o')
        for i in range(1, n):
            plt.plot(tenors_last, entries_lists[i], label=f'Weight Curve {i}', marker='o')
        plt.plot(tenors_last, prices_plot, label='Price Curve', marker='o')
        plt.plot(tenors_last, real_price, label= "Real price Curve", marker= "x")

        plt.xlabel('Time to maturity')
        plt.ylabel('Values')
        # plt.title('Entries and Multiplied Entries vs Tenors Last')
        plt.legend()
        plt.grid(True)
        plt.show()

    plot_base_weight()



base_weight(tenors, optimized_weights, df_zcb_sorted, optimized_z, pred_pd,n)