import os
import random
import pandas as pd
import tensorflow as tf
import numpy as np
from keras.layers import Input, Dense, Lambda, Reshape, Dot
import keras
from keras.optimizers import Adam
from keras.models import Model
from ann_visualizer.visualize import ann_viz
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
from statsmodels.nonparametric.smoothers_lowess import lowess
import matplotlib.dates as mdates

#Set seed for reproducibility
seed_value = 50
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

# Set the PYTHONHASHSEED environment variable for further consistency
os.environ['PYTHONHASHSEED'] = str(seed_value)

start_date = "2019-01-01"
end_date = "2022-12-31"

df_zcb_og = pd.read_csv("C:\\Users\\giaco\\Desktop\\tesi\\data bloomberg\\price_all_05.csv")
df_zcb_09_11 = df_zcb_og[(df_zcb_og['Dates'] >= start_date) & (df_zcb_og['Dates'] <= end_date)]
dates_og = df_zcb_09_11["Dates"]
df_zcb  =df_zcb_09_11.drop(columns="Dates")


ttm_zcb_og = pd.read_csv("C:\\Users\\giaco\\Desktop\\tesi\\data bloomberg\\ttm_all_05.csv")
ttm_zcb_09_11 = ttm_zcb_og[(ttm_zcb_og['Dates'] >= start_date) & (ttm_zcb_og['Dates'] <= end_date)]
ttm_zcb = ttm_zcb_09_11.drop(columns="Dates")


ttm_zcb_sort = ttm_zcb.apply(lambda row: pd.Series(sorted(row)), axis=1)


# Calculate the sorting indices for each row in ttm_zcb
sort_indices = ttm_zcb.apply(np.argsort, axis=1)

# Use the indices to sort df_zcb in the same way
df_zcb_sorted = pd.DataFrame([df_zcb.iloc[i].values[indices] for i, indices in enumerate(sort_indices.values)], index=df_zcb.index)

t_bill_prices_np = df_zcb_sorted.to_numpy()
t_bill_prices_ts_list = [tf.constant(t_bill_prices_np[:, i:i+1], dtype=tf.float32) for i in range(t_bill_prices_np.shape[1])] # create a list
real_p_target = tf.convert_to_tensor(t_bill_prices_ts_list) # convert to tensor data


t_bill_tenors = ttm_zcb_sort.astype(float)
t_bill_tenors = t_bill_tenors.to_numpy()
tenors = tf.convert_to_tensor(t_bill_tenors) # convert to tensor data




#### Parameters
M = t_bill_tenors.shape[1]   #number of bonds
N = t_bill_tenors.shape[0]  ## Number of observation dates




def build_scalar_model(n):

        # define the inputs of the model
        x_in = Input(shape=(1,), name='tenor') # 1 dimensional array
        z_in = Input(shape=(n,), name='state factor') # 1 dimensional array with 2 objects

        # build x*A, i.e. input x times a 1 times n^2 matrix
        # dense layer hyperparameters (no activation specified and no bias)
        n_neurons = n ** 2
        A_vec = Dense(units=n_neurons, use_bias=False)(x_in)
        # reorder the matrix x*A to an n times n matrix
        A = Reshape((n, n))(A_vec)
        # Calculate the matrix exponential exp(x*A)
        # Lambda wraps functions as keras layers
        exp_xA = Lambda(lambda x: tf.linalg.expm(x))(A)

        # obtain first row e_0*expm(x*A) of the matrix exponential exp(x*A)
        # Note: first dimension are for parallel computations and, we want them all
        # Second dimension are for the rows of the resulted matrix
        # Third dimension are for the columns of the resulted matrix

        e_exp_xA = exp_xA[:, 0, :]  # pick first row
        # obtain scalar product (e_0*expm(x*A))*z of the first row e_0*expm(x*A) with z)
        p = Dot(axes=1)([e_exp_xA, z_in])
        # Build the model p = e_0*expm(x*A)*z
        return Model(inputs=[x_in, z_in], outputs=p)  # it groups all the layers and define the model



def build_vectormodel(pricemodel,n):
    x_in = Input(shape=(M,), name='tenor')
    z_in = Input(shape=(n,), name='state factor')
    p = []   #list of prices
    for i in range(M):
        p = p + [pricemodel([x_in[:, i], z_in])]  # all the values of x in that column, all rows but only one column at time
    return(Model(inputs = [x_in, z_in], outputs = p))



# loss function
def loss_function(y_true, y_pred):
    return tf.keras.losses.mean_squared_error(y_true, y_pred)


# optimizer
optimizer = Adam(learning_rate=0.01)



# Use TensorFlow GradientTape to compute gradients
def compute_gradients(pricevec, x_train, z_trainable, real_p_target):
    with tf.GradientTape() as tape:
        p_pred = pricevec([x_train, z_trainable])
        loss = loss_function(real_p_target, p_pred)
    gradients = tape.gradient(loss, pricevec.trainable_variables + [z_trainable])
    return gradients


# Function for training loop using gradient descent
def update_z_weights(pricevec, x_train, z_trainable, epochs=100, silent=True):
    optimizer = Adam(learning_rate=0.01)
    for epoch in range(epochs):
        if not silent:
            print(epoch, "/", epochs, "...", end="")
        with tf.GradientTape() as tape:
            p_pred = pricevec([x_train, z_trainable])
            loss = loss_function(real_p_target, p_pred)
        gradients = tape.gradient(loss, pricevec.trainable_variables + [z_trainable])
        optimizer.apply_gradients(zip(gradients, pricevec.trainable_variables + [z_trainable]))
        z_trainable.assign(tf.concat([tf.ones((len(x_train), 1)), z_trainable[:, 1:]], axis=1))



def train(pricemodel, pricevec, x_train, z_trainable, real_p_target, epochs=50, maxLoss=0.001, tries=10, verbose=1):
    silent = True
    if verbose == 1:
        silent = False
    if verbose != 0:
        print("Attempting to reach a loss of at most", maxLoss, "with", epochs, "(adaptive) gradient descent steps.\nIf loss is not reached, repeat up to", tries, "times.")
    loss_vec = []
    for k in range(tries):
        Loss = np.mean(loss_function(real_p_target, pricevec([x_train, z_trainable])))  #
        loss_vec.append(Loss)
        if verbose != 0:
            print("(MSE) Loss after", k, "attempt(s):", Loss, "\n")
        if Loss > maxLoss:
            if verbose != 0:
                print("Updating parameters with another", epochs, "gradient descent steps!")
            update_z_weights(pricevec, x_train, z_trainable, epochs, silent)
            if Loss <= maxLoss:
                break
    optimized_weights = [var.numpy() for var in pricemodel.trainable_variables]
    optimized_z = z_trainable.numpy()
    return optimized_weights, optimized_z, loss_vec




def errror_plot(pricevec, x_train, optimized_z, real_p_target):
    p_target_s = np.squeeze(real_p_target)
    p_pred_list = pricevec([x_train, optimized_z])
    p_pred = np.transpose(np.column_stack(p_pred_list))
    deviation = p_pred - p_target_s
    err = np.mean((deviation)**2)
    return np.sqrt(err), p_pred



def rmse_loop(zcb, ttm, n_dim):
    pred_prices_list = []
    RMSE_list = []
    loss_list = []
    optimized_weight_list = []
    M = t_bill_tenors.shape[1]
    N = t_bill_tenors.shape[0]
    for dim in range(1, n_dim):
        pricemodel = build_scalar_model(dim)
        pricevec = build_vectormodel(pricemodel, dim)
        x_train = ttm
        z_trainable = tf.Variable(tf.ones((N, dim)))
        optimized_weights, optimized_z, loss_vec = train(pricemodel, pricevec, x_train, z_trainable, zcb, epochs=30, maxLoss=0.00000001, tries=2, verbose=1)
        RMSE, predic_price = errror_plot(pricevec, x_train, optimized_z, zcb)
        loss_list.append(loss_vec)
        RMSE_list.append(RMSE)
        pred_prices_list.append(predic_price)
        optimized_weight_list.append(optimized_weights)
    return pred_prices_list, RMSE_list, loss_list, optimized_weight_list

pred_price_list, rmse_list, loss_dim, matrix_A = rmse_loop(real_p_target, tenors, 9)


#store the correct dimensions in different vectors

#arithmetic average
transposed_data = np.transpose(loss_dim)
# Calculate the mean of each row in the transposed data
row_means_mse = np.mean(transposed_data, axis=1)


# df_12dim_15_steps = pd.DataFrame(loss_dim)

def plot_mse():
    plt.figure(figsize=(10, 6))
    plt.plot(row_means_mse, marker='o', linestyle='-', color='b', markerfacecolor='r', label='MSE values')
    plt.title('Mean squared error reduction after n iterations')
    plt.xlabel('Iteration')
    plt.ylabel('MSE')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

plot_mse()

def plot_RMSE(list_rmse):
    dimensions = [f'd={i}' for i in range(1, len(list_rmse) + 1)]
    x = np.arange(1, len(list_rmse) + 1)
    y = np.array(list_rmse)

    # Create a smooth line using lowess smoothing
    lowess_smoothed = lowess(y, x, frac=0.5)  # Adjust frac for smoother or less smooth line

    plt.figure(figsize=(10, 6))
    plt.plot(x, y, marker='o', linestyle='-', color='b', markerfacecolor='r', label='RMSE values')
    plt.xticks(x, dimensions)
    plt.xlabel('Dimension')
    plt.ylabel('RMSE')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

plot_RMSE(rmse_list)


