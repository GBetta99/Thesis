import math
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.ticker import ScalarFormatter

#simulation with parameters estimated with YUIMA package
parameters_cir = pd.read_csv('C:\\Users\\giaco\Desktop\\tesi\data bloomberg\\coef_cir_12_22.csv', delimiter=',')
sigma = parameters_cir.iloc[0,1]
kappa = parameters_cir.iloc[1,1]
mu = parameters_cir.iloc[2,1]

#import last value of Z
Z_values = np.load('C:\\Users\\giaco\Desktop\\tesi\data bloomberg\\z_vector_1d_12_22.npy')



M = 365 #number step
dt = 1/M
I = 1000 #number of simulations
x0 = Z_values[-1]
#
# Simulation of Square Root Diffusion  (Euler mauriama)
#

#Euler discretizaion
def CIR_generate_paths(x0, kappa, theta, sigma, dt, M, I):
    np.random.seed(50)
    x = np.zeros((M + 1, I), dtype=float)
    x[0] = x0
    xh = np.zeros_like(x)
    xh[0] = x0
    ran = np.random.standard_normal((M, I))

    # Euler scheme (full truncation)
    for t in range(1, M + 1):
        xh[t] = (xh[t - 1] + kappa * (theta - np.maximum(0, xh[t - 1])) * dt
                 + np.sqrt(np.maximum(0, xh[t - 1])) * sigma * ran[t - 1] * math.sqrt(dt))
        x[t] = np.maximum(0, xh[t])

    return x

paths_euler = CIR_generate_paths(x0, kappa, mu, sigma, dt, M, I)


def plot_simulated_paths(simulated_paths):
    plt.figure(figsize=(12, 8))

    # Use shades of blue for the paths
    for path in simulated_paths.T:
        plt.plot(path, alpha=0.05, color='blue')

    plt.xlabel('Time')
    plt.ylabel('Z')
    plt.gca().xaxis.set_major_formatter(ScalarFormatter(useOffset=False))
    plt.gca().yaxis.set_major_formatter(ScalarFormatter(useOffset=False))
    plt.grid(True)
    plt.legend()
    plt.show()


plot_simulated_paths(paths_euler)

