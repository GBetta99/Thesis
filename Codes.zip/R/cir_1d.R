#packages
require(reticulate)
require(yuima)
require(rstudioapi)
require(ggplot2)
library(reshape2)
options(scipen = 9999)

#wd and load  ----

setwd(dirname(getActiveDocumentContext()$path))

#import module
np <- import("numpy")

Z <- np$load("z_vector_1d_12_22.npy")

n_simulations <- 1000



sol <- c("x")
drift_1 <- c("kappa1 * (mu1 - x)")
diff <- matrix(c("sigma*sqrt(x)"), 1, 1)


#sampling (delta t)
samp <- setSampling(Terminal = 1, n = 365)

#model
model_z <- setModel(drift = drift_1, diffusion = diff, solve.variable = sol)


#yuima object 
my_yuima <- setYuima(data = setData(Z), model = model_z)


param.init <- list(kappa1 = 0.0000000001, mu1 = mean(Z),  sigma=sd(Z)) 
low.par <- list(kappa1 = 0.000000001, mu1 = -5,  sigma=-5)
upp.par <- list(kappa1 = 5, mu1 = 5,  sigma=5)

mle1 <- yuima::qmle(my_yuima, start = param.init, lower = low.par, upper = upp.par,
                    method = "L-BFGS-B", 
                    print = TRUE)



coef_est <- coef(mle1)
sigma = coef_est["sigma"]
kappa1 =  coef_est["kappa1"]
mu1 = coef_est["mu1"]


set.seed(50)

simulations <- vector("list", n_simulations)


for (i in 1:n_simulations) {
  simu <- simulate(model_z, sampling = samp, xinit = Z[length(Z)], true.parameter = list(kappa1 = kappa1,
                                                                                         mu1 = mu1,
                                                                                         sigma = sigma))
  simulations[[i]] <- simu@data@original.data
}



# Convert list to a matrix
sim_matrix <- sapply(simulations, function(sim) sim[,1])
time <- index(simu@data@original.data)  
# Compute the average path
average_path <- rowMeans(sim_matrix)


# Plot the average path
plot(time, average_path, type = "l", col = "blue", xlab = "Time", ylab = "Average X_t", main = "Average of 1000 Simulated Paths")

#Plot all the paths
df_simu <- as.data.frame(sim_matrix)
df_simu$Time <- time

# Melt the data frame to long format
df_long <- melt(df_simu, id.vars = "Time", variable.name = "Path", value.name = "Value")

# Plot all paths
ggplot(df_long, aes(x = Time, y = Value, group = Path)) +
  geom_line(alpha = 0.1, size = 0.5, color = "blue") +
  labs(x = "Time", y = "Z") +
  theme_bw() +  # Use theme_bw for a similar style
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.5),
    panel.grid.major = element_line(color = "grey80"),
    panel.grid.minor = element_line(color = "grey90")
  )


