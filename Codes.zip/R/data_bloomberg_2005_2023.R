rm(list = ls())
library(rstudioapi)
library(readxl)
library(dplyr)
library(lubridate)
library(stringr)
library(tidyr)
library(ggplot2)
setwd(dirname(getActiveDocumentContext()$path))



# Load the dataset with all the maturity date from 2005 to 2024 (there were only 4, 13, 26 and 52 weeks)
og_df <- read_excel("bills_2005_2024.xlsx", col_names = TRUE)


# Including weekend and using forward filling (to calculate the correct TTM)
all_dates <- seq(as.Date("2005-01-03"), as.Date("2024-05-02"), by = "day")
date_df <- data.frame(Dates = all_dates)



#join datasets 
df <- date_df %>%
  left_join(og_df, by = "Dates")

#forward filling 
df <- fill(df, names(df))

# Function to place NA values after expiration date of each T-bill
process_tbill_column <- function(data, column_name) {
  # Extract expiration date from the column name
  exp_date_str <- gsub("B (\\d{2}/\\d{2}/\\d{2}) Govt", "\\1", column_name)
  exp_date <- mdy(exp_date_str) #function from lubridate 
  
  # Replace values after the expiration date with NA
  data <- data %>%
    mutate(!!sym(column_name) := ifelse(Dates >= exp_date, NA_real_, !!sym(column_name)))
  
  return(data)
}

# Process each T-Bill column, skipping the first column (Dates)
for(column_name in colnames(df)[-1]) {
  df <- process_tbill_column(df, column_name)
}

# convert #N/A N/A to just NA
df <- df |> 
  mutate(across(where(is.character), ~ifelse(str_detect(., "#N/A N/A"), NA, .)))



#creates new df for TTm
df$Dates <- as.Date(df$Dates)
ttm <- df



ttm_fun <- function(bond_column, col_name) {
  n <- length(bond_column)
  
  days_to_maturity <- rep(NA, n)
  
  issuance_idx <- which(!is.na(bond_column))[1]
  
  maturity_idx <- max(which(!is.na(bond_column)))
  
  
  days_to_maturity[issuance_idx:maturity_idx] <- (maturity_idx-issuance_idx+1 ):1
  
  #case in which the bond expires after the end of the dataset 
  
  if (maturity_idx == n){
    exp_date_str <- gsub("B (\\d{2}/\\d{2}/\\d{2}) Govt", "\\1", col_name)
    exp_date <- mdy(exp_date_str) #function from lubridate 
    
    for (i in issuance_idx:maturity_idx) {
      days_to_maturity[i] <- as.integer(exp_date - df$Dates[i])
    }
    
    # days_to_maturity[issuance_idx:maturity_idx] <- exp_date - df$Dates[issuance_idx] : exp_date - df$Dates[maturity_idx]
  }
  
  return(days_to_maturity)
}

ttm_fun_2 <- function(df, col_name){
  for (i in 2:ncol(df)){
    df[,i] <- ttm_fun(df[,i], col_name[i])
  }
  return(df)
}

ttm <- ttm_fun_2(ttm, names(ttm))


max_values <- apply(ttm[,-1], 1, function(x) max(x, na.rm = TRUE))
df_max <- data.frame(Dates=ttm[,1], max_ttm = max_values)


global_max_22 <- max(df_max[1:7060,]$max_ttm, na.rm = TRUE)
global_min_22 <- min(df_max[1:7060,]$max_ttm, na.rm = TRUE)



#Normally how was the TTm 
plot_ttm_22 <- ggplot(df_max[1:7060,], aes(x=Dates, y=max_ttm)) +
  geom_line(color = "blue") +  
  geom_hline(yintercept = global_max_22, linetype = "dashed", color = "green") +
  geom_hline(yintercept = global_min_22, linetype = "dashed", color = "red") +
  scale_y_continuous(breaks = function(x) unique(c(pretty(x), global_max_22, global_min_22))) + # Customize y breaks
  labs(x = "Time", y = "Max time to maturity") +
  theme_minimal()


plot_ttm_22 # We can see when



#In the last year, since we were not taking new bond issued it makes sense that the time to maturity decreases steeply 

global_max_24 <- max(df_max[6700:nrow(df_max),]$max_ttm, na.rm = TRUE)
global_min_24 <- min(df_max[6700:nrow(df_max),]$max_ttm, na.rm = TRUE)

plot_ttm_24 <- ggplot(df_max[6700:nrow(df_max),], aes(x=Dates, y=max_ttm)) +
  geom_line(color = "blue") +  
  geom_hline(yintercept = global_max_24, linetype = "dashed", color = "green") +
  geom_hline(yintercept = global_min_24, linetype = "dashed", color = "red") +
  scale_y_continuous(breaks = function(x) unique(c(pretty(x), global_max_24, global_min_24))) + # Customize y breaks
  labs(title = "Maximum TTM by Date", x = "Date", y = "Maximum TTM") +
  theme_minimal()
# plot_ttm_24



#Number of "active maturity date", note that since more than one bond exists for each maturity date then to know the exact number of bonds we should investigate more

active_bond_fun <- function(df){
  n_col <- numeric(0)
  for (i in 1:nrow(df)){
    non_na_columns <- colSums(is.na(df[i,-1])) == 0
    df_temp <- df[i, non_na_columns]
    active_col <- ncol(df_temp)
    n_col <- c(n_col, active_col)
  }
  return(data.frame(Dates=df[,1],active_mat=n_col))
}

active_mat <- active_bond_fun(ttm)


plot_active_mat <- ggplot(active_mat, aes(x=Dates, y=active_mat)) +
  geom_line(color = "blue") +  # Customize y breaks
  labs(title = "Number of Maturity Dates with at least one traded T-Bill", x = "Date", y = "Maturity Dates Number") +
  theme_minimal()
plot_active_mat



# Now I need to calculate the real price of each T-bill because in the secondary market they are quoted differently
# T-Bills are sold at auction and do not pay coupon (are sell at discount)

#In my dataset the yield expressed refers to the price of last transaction of the day
# We can use the formula 1/1+ yield * ttm to get the real price
# We are sure that this conversion reflects the real price because the price of the issue date (auction price on the US website) corresponds to the price calculate here, the small differences are due to the calculation of TTM and its representation in terms of year (US doesn't say anything)

#First, following the most common convention we express the TTM in terms of year (divide by 365)

ttm_year <- ttm |> 
  mutate(across(-1, ~./365))



df[,-1] <- lapply(df[,-1], as.numeric)
ttm_year[,-1] <- lapply(ttm_year[,-1], as.numeric)



#We express the price price in explicit way, reflecting negative interest rates (multiply by -1)

numeric_columns <- sapply(df[-1], is.numeric)

# Multiply negative values by -1 excluding dates
df[-1][numeric_columns] <- lapply(df[-1][numeric_columns], function(column) {
  # Replace negative values with their positive counterparts
  column <- ifelse(is.na(column), column, ifelse(column < 0, column * -1, column))
  return(column)
})


df_price <- 1 / (1 + df[, -1] / 100 * ttm_year[, -1])


df_price <- cbind(df[, 1], df_price)
names(df_price)[1] <- "Dates"

# write.csv(df_price, "all_bills_prices_05.csv", row.names = FALSE, quote = FALSE)
# write.csv(ttm_year, "all_bills_ttm_05.csv", row.names = FALSE, quote = FALSE)





#Now we can create a dataset for each type of T-bill


#Maturity date from 05/05/05 to 04/17/25
auc_4_w <- read.csv("C:/Users/giaco/Desktop/tesi/data bloomberg/auc_4_05.csv")
auc_13_w <- read.csv("C:/Users/giaco/Desktop/tesi/data bloomberg/auc_13_05.csv")
auc_52_w <- read.csv("C:/Users/giaco/Desktop/tesi/data bloomberg/auc_52_05.csv")


#until end of 2018 4,13, and 26 had same maturity date

mat_4_w <- auc_4_w |> 
  select(Maturity.Date) |> 
  rename(mat_date = Maturity.Date) |> 
  mutate(mat_date = as.Date(mat_date, format="%m/%d/%Y")) |> 
  mutate(mat_date = format(mat_date, format="%m/%d/%y"))


mat_13_26_w <- auc_13_w |> 
  select(Maturity.Date) |> 
  rename(mat_date = Maturity.Date) |> 
  mutate(mat_date = as.Date(mat_date, format="%m/%d/%Y")) |> 
  mutate(mat_date = format(mat_date, format="%m/%d/%y"))



mat_52_w <- auc_52_w |> 
  select(Maturity.Date) |> 
  rename(mat_date = Maturity.Date) |> 
  mutate(mat_date = as.Date(mat_date, format="%m/%d/%Y")) |> 
  mutate(mat_date = format(mat_date, format="%m/%d/%y"))



#check the maturities , 4 weeks and 13 weeks start to diverge after 12/06/18
check_maturity <- cbind(mat_13_26_w[9:nrow(mat_13_26_w),], mat_4_w)



new_df_fun <- function(df, auc) {
  
  # Initialize a vector to store indices of columns to keep
  cols_to_keep <- integer(0)
  
  for (i in 2:ncol(df)) {
    exp_date_str <- gsub("B (\\d{2}/\\d{2}/\\d{2}) Govt", "\\1", names(df)[i])
    
    # Debug: Print out the extracted date string and the converted date
    print(paste("Column name:", names(df)[i]))
    print(paste("Extracted date string:", exp_date_str))
    print(paste("Converted date:", exp_date_str))
    
    if (!is.na(exp_date_str) && exp_date_str %in% auc[,1]) {
      cols_to_keep <- c(cols_to_keep, i)
    }
  }
  
  # Debug: Print out which columns are selected to keep
  print(paste("Columns to keep indices:", toString(cols_to_keep)))
  
  # Subset df based on cols_to_keep
  new_df <- df[, cols_to_keep, drop = FALSE]
  
  # Check if new_df is empty
  if(ncol(new_df) == 0) {
    print("No columns were added to new_df. Check date formats and matching conditions.")
  }
  
  return(new_df)
}


dates <- as.data.frame(df_price$Dates)
names(dates)[1] <- "Dates"

#First 52-Weeks 06/04/2009, so after crisis

#prices
t_bills_4_w_price <- cbind(dates ,new_df_fun(df_price, mat_4_w))
t_bills_13_26_w_price <- cbind(dates, new_df_fun(df_price, mat_13_26_w))
t_bills_52_w_price <- cbind(dates, new_df_fun(df_price, mat_52_w))

#TTM
t_bills_4_w_ttm <- cbind(dates ,new_df_fun(ttm_year, mat_4_w))
t_bills_13_26_w_ttm <- cbind(dates, new_df_fun(ttm_year, mat_13_26_w))
t_bills_52_w_ttm <- cbind(dates, new_df_fun(ttm_year, mat_52_w))



#Now I  create a function for 26 weeks

#function to keep only  columns with bonds without the NA values (only for 26 weeks bonds)
all_26_fun <- function(df){
  for (j in 1:50){
    for (i in 2:(ncol(df)-26)) { 
      na_indexes <- is.na(df[, i])
      df[na_indexes, i] <- df[na_indexes, i+26]
    }
  }
  return(df)
} 

#Before we don't have 26 columns
t_bills_13_26_w_price <- t_bills_13_26_w_price |> 
  filter(Dates > "2005-05-05")

t_bills_13_26_w_ttm <- t_bills_13_26_w_ttm |> 
  filter(Dates > "2005-05-05")

new_column_names <- paste0("bond", 1:26)
price_26_w <- all_26_fun(t_bills_13_26_w_price)[,1:27]
colnames(price_26_w)[2:27] <- new_column_names
ttm_26_w <- all_26_fun(t_bills_13_26_w_ttm)[,1:27]
colnames(ttm_26_w)[2:27] <- new_column_names

# just to see how the price change 
ggplot(price_26_w, aes(x = Dates, y = price_26_w[,2])) +
  geom_line(color = "blue") +  
  theme_minimal()




#now I  create a function for 8 weeks

#function to keep only  columns with bonds without the NA values (only for 8 weeks bonds), only after 12/06/2018 because before the values were inside 26 weeks.

all_4_fun <- function(df){
  for (j in 1:60){
    for (i in 2:(ncol(df)-8)) { 
      na_indexes <- is.na(df[, i])
      df[na_indexes, i] <- df[na_indexes, i+8]
    }
  }
  return(df)
} 

t_bills_4_w_price_filt <- t_bills_4_w_price[5091:nrow(t_bills_4_w_price), c(1,712:ncol(t_bills_4_w_price))]

t_bills_4_w_ttm_filt <- t_bills_4_w_ttm[5091:nrow(t_bills_4_w_ttm), c(1,712:ncol(t_bills_4_w_ttm))]
    

new_column_names <- paste0("bond", 1:8)
price_4_w <- all_4_fun(t_bills_4_w_price_filt)[,1:9]
colnames(price_4_w)[2:9] <- new_column_names
ttm_4_w <- all_4_fun(t_bills_4_w_ttm_filt)[,1:9]
colnames(ttm_4_w)[2:9] <- new_column_names


# just to see how the price change 
ggplot(price_4_w, aes(x = Dates, y = price_4_w[,2])) +
  geom_line(color = "blue") +  
  theme_minimal()





#function to keep only 13 columns with bonds without the NA values (only for 52 weeks bonds)

#First issued in 2008/06/03

t_bills_52_w_price_filt <- t_bills_52_w_price|> 
  filter(Dates > "2009-06-03")

t_bills_52_w_ttm_filt <- t_bills_52_w_ttm |> 
  filter(Dates > "2009-06-03")



all_52_fun <- function(df){
  for (j in 1:40){
    for (i in 2:(ncol(df)-13)) { 
      na_indexes <- is.na(df[, i])
      df[na_indexes, i] <- df[na_indexes, i+13]
    }
  }
  return(df)
}  

new_column_names <- paste0("bond", 1:13)
price_52_w <- all_52_fun(t_bills_52_w_price_filt)[,1:14]
colnames(price_52_w)[2:14] <- new_column_names
ttm_52_w <- all_52_fun(t_bills_52_w_ttm_filt)[,1:14]
colnames(ttm_52_w)[2:14] <- new_column_names

# just to see how the price change 
ggplot(price_52_w, aes(x = Dates, y = price_52_w[,2])) +
  geom_line(color = "blue") +  
  theme_minimal()




#we can create an entire dataset with all bonds (all maturities) excluding days for which we don't have all the data 

#First we need to start from Dates > 2009-06-03

new_price_13_26_w <- price_26_w |> 
  filter(Dates > "2009-06-03")

new_ttm_13_26_w <- ttm_26_w |> 
  filter(Dates > "2009-06-03")



#Now I take 8 columns of the 26 week price from the beginning until 2018-12-11

new_price_4 <- new_price_13_26_w |> 
  filter(Dates<"2018-12-11") |> 
  select(c(1:9)) |> 
  rbind(price_4_w[1:9])


new_ttm_4_w <- new_ttm_13_26_w |> 
  filter(Dates<"2018-12-11") |> 
  select(c(1:9)) |> 
  rbind(ttm_4_w[1:9])




#We remove after "2024-01-25" to avoid NA values
price_all <- cbind(new_price_13_26_w, new_price_4[,2:ncol(new_price_4)], price_52_w[,2:ncol(price_52_w)])
colnames(price_all)[2:48] <- paste0("bond", 1:47)
price_all <-  price_all |> 
  filter(Dates < "2024-01-25")


ttm_all <- cbind(new_ttm_13_26_w, new_ttm_4_w[,2:ncol(new_ttm_4_w)], ttm_52_w[,2:ncol(ttm_52_w)])
colnames(ttm_all)[2:48] <- paste0("bond", 1:47)
ttm_all <- ttm_all |> 
  filter(Dates< "2024-01-25")


# write.csv(price_all, file = "price_all_05.csv", row.names = FALSE, quote = FALSE)
# write.csv(ttm_all, file = "ttm_all_05.csv", row.names = FALSE, quote = FALSE)
