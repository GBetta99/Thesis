#packages
require(reticulate)
require(yuima)
require(rstudioapi)
require(ggplot2)
library(reshape2)
library(sde)
library(stats)
options(scipen = 9999)

#wd and load  ----

setwd(dirname(getActiveDocumentContext()$path))

#import module
np <- import("numpy")

Z <- np$load("z_vector_1d_12_22.npy")


n_simulations <- 1000


sol <- c("x")
drift_1 <- c("kappa1 * (mu1 - x)")
diff <- matrix(c("sigma"), 1, 1)


#sampling (delta t)
samp <- setSampling(Terminal = 1, n = 365)

#model
model_z <- setModel(drift = drift_1, diffusion = diff, solve.variable = sol)


#yuima object 
my_yuima <- setYuima(data = setData(Z), model = model_z)


param.init <- list(kappa1 = 0, mu1 = mean(Z),  sigma=sd(Z)) 
low.par <- list(kappa1 = 0, mu1 = -10,  sigma=-10)
upp.par <- list(kappa1 = 1, mu1 = 10,  sigma=10)

mle1 <- yuima::qmle(my_yuima, start = param.init, lower = low.par, upper = upp.par,
                    method = "L-BFGS-B", 
                    print = TRUE)

summary(mle1)

coef_est <- coef(mle1)
sigma = coef_est["sigma"]
kappa1 =  coef_est["kappa1"]
mu1 = coef_est["mu1"]


set.seed(50)

simulations <- vector("list", n_simulations)


for (i in 1:n_simulations) {
  simu <- simulate(model_z, sampling = samp, xinit = Z[length(Z)], true.parameter = list(kappa1 = kappa1,
                                                                                         mu1 = mu1,
                                                                                   sigma = sigma))
  simulations[[i]] <- simu@data@original.data
}



# Convert list to a matrix
sim_matrix <- sapply(simulations, function(sim) sim[,1])
time <- index(simu@data@original.data)  
# Compute the average path
average_path <- rowMeans(sim_matrix)
 

plot(time, average_path, type = 'l', col = 'blue', ylim = range(average_path), 
     xlab = 'Time', ylab = 'Z1 value', lwd = 2) # lwd for line width



#Plot all the paths
df_simu <- as.data.frame(sim_matrix)
df_simu$Time <- time

# Melt the data frame to long format
df_long <- melt(df_simu, id.vars = "Time", variable.name = "Path", value.name = "Value")

# Plot all paths
ggplot(df_long, aes(x = Time, y = Value, group = Path)) +
  geom_line(alpha = 0.1, size = 0.5, color = "blue") +
  labs(x = "Time", y = "Z") +
  theme_bw() +  # Use theme_bw for a similar style
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.5),
    panel.grid.major = element_line(color = "grey80"),
    panel.grid.minor = element_line(color = "grey90")
  )



### Exact simulation ----

mu <- mu1    
theta <- 0.0000000000001
sigma <- sigma   
dt <- 1/365    
last_T <- 1         
n <- 365    

# Time vector
time <- seq(0, last_T, by = dt)


# Number of simulations
num_simulations <- 1000

# Initialize the matrix to store simulations
X <- matrix(0, nrow = length(time), ncol = num_simulations)

# Initial value
X[1, ] <- Z[length(Z)]

# Simulate the process
for (t in 2:length(time)) {
  epsilon <- rnorm(num_simulations)
  X[t, ] <- X[t-1, ] * exp(-theta * dt) + mu * (1 - exp(-theta * dt)) + 
    sigma * sqrt((1 - exp(-2 * theta * dt)) / (2 * theta)) * epsilon
}

# Convert the matrix to a data frame for ggplot2
df <- as.data.frame(X)
df$time <- time
df_melt <- melt(df, id.vars = 'time')

# Plot the process
ggplot(df_melt, aes(x = time, y = value, group = variable)) + 
  geom_line(alpha = 0.1, color = "blue") + 
  xlab("Time") + ylab("Z") + 
  theme_minimal()

# write.csv(average_path[2:length(average_path)], file = "simulation_1d.csv", row.names = FALSE, quote = FALSE)  #I don't keep the first value



