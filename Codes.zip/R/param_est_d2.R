#packages
require(reticulate)
require(yuima)
require(rstudioapi)
library(ggplot2)
library(reshape2)

#wd and load  ----

setwd(dirname(getActiveDocumentContext()$path))

#import module
np <- import("numpy")

Z <- np$load("z_vector_2d_19_22.npy") #select vector

n_simulations <- 1000



sol <- c("x1", "x2")

drift_1 <- c("kappa11 * (mu1-x1) + kappa12*(mu2 - x2)", "kappa22*(mu1 - x1) + kappa21*(mu2 - x2)") 


diff <- matrix(c("sigma11","rho12","rho21","sigma22"), 2, 2) 



#sampling (delta t)
samp <- setSampling(Terminal = 1, n = 365)

#model
model_z <- setModel(drift = drift_1, diffusion = diff, solve.variable = sol, state.variable = sol)


#yuima object 
my_yuima <- setYuima(data = setData(Z), model = model_z)


param.init <- list(sigma11 = sd(Z[,1]), rho12 = 0, sigma22 = sd(Z[,2]), rho21 = 0,
                   mu1 = mean(Z[,1]), mu2 = mean(Z[,2]), kappa11  = 0, kappa22  = 0, 
                   kappa12 = 0, kappa21 = 0) 

low.par <- list(sigma11 = -10, rho12 = -10, sigma22 = -10,
                mu1 = -10, mu2 = -10, kappa11  = 0, kappa22  = 0, rho21 = -10,
                kappa12 = 0, kappa21 = 0)

upp.par <- list(sigma11 = 10, rho12 = 10, sigma22 = 10, rho21 = 10,
                mu1 = 10, mu2 = 10, kappa11  = 10, kappa22  = 10, 
                kappa12 = 10, kappa21 = 10)

mle1 <- yuima::qmle(my_yuima, start = param.init, lower = low.par, upper = upp.par,
                    method = "L-BFGS-B",                     print = TRUE)


coeff_sigma_2 <- coef(mle1)
sigma11 <- coeff_sigma_2["sigma11"]
sigma22 <- coeff_sigma_2["sigma22"]
rho12 <- coeff_sigma_2["rho12"]
rho21 <- coeff_sigma_2["rho21"]
kappa11 = coeff_sigma_2["kappa11"]
kappa22 = coeff_sigma_2["kappa22"]
kappa12 = coeff_sigma_2["kappa12"]
kappa21 = coeff_sigma_2["kappa21"]
mu1 = coeff_sigma_2["mu1"]
mu2 = coeff_sigma_2["mu2"]


set.seed(50)

simulations <- vector("list", n_simulations)


for (i in 1:n_simulations) {
  simu <- simulate(model_z, sampling = samp, xinit = Z[nrow(Z),], true.parameter = list(kappa11 = kappa11, kappa22 = kappa22, kappa12 = kappa12, kappa21 = kappa21, mu1 = mu1, mu2 = mu2,
                                                                                        sigma11=sigma11, rho12=rho12, sigma22 = sigma22, rho21 = rho21))
  simulations[[i]] <- simu@data@original.data
}



# Convert list to a matrix
sim_matrix_1 <- sapply(simulations, function(sim) sim[,1])
sim_matrix_2 <- sapply(simulations, function(sim) sim[,2])
time <- index(simu@data@original.data)  #time index 

# Compute the average path
average_path_1 <- rowMeans(sim_matrix_1)
average_path_2 <- rowMeans(sim_matrix_2)
average_path_all <- cbind(average_path_1, average_path_2)
correlation <- cor(average_path_all[, 1], average_path_all[, 2])

# Create the plot with dual y-axes
plot(time, average_path_1, type = 'l', col = 'blue', ylim = range(average_path_1), 
     xlab = 'Time', ylab = 'Z1 value')

# Add the second path
par(new = TRUE)
plot(time, average_path_2, type = 'l', col = 'red', ylim = range(average_path_2), 
     axes = FALSE, xlab = "", ylab = "")
axis(side = 4)
mtext("Z2 value", side = 4, line = 3)

# Add legend inside plot area and correlation value
legend('topright', legend = c('Z1', "Z2"), col = c('blue', 'red'), lty = 1, cex = 0.8, box.lty = 0, inset = c(0.02, 0.02))
text(x = 0.8, y = 0.91090, labels = paste('Correlation:', round(correlation, 4)), cex = 0.8)




#Plot all the paths
df_simu <- as.data.frame(sim_matrix_2)
df_simu$Time <- time

# Melt the data frame to long format
df_long <- melt(df_simu, id.vars = "Time", variable.name = "Path", value.name = "Value")

# Plot all paths
ggplot(df_long, aes(x = Time, y = Value, group = Path)) +
  geom_line(alpha = 0.1, linewidth = 0.10, color = "blue") +
  labs(x = "Time", y = "Z") +
  theme_bw() +  # Use theme_bw for a similar style
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.10),
    panel.grid.major = element_line(color = "grey80"),
    panel.grid.minor = element_line(color = "grey90")
  )
