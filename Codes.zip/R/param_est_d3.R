#packages
require(reticulate)
require(yuima)
require(rstudioapi)
require(ggplot2)
library(tidyr)
library(plotrix)
library(plotly)


#wd and load  ----

setwd(dirname(getActiveDocumentContext()$path))

#import module
np <- import("numpy")

Z <- np$load("z_vector_3d_19_22.npy")

n_simulations <- 1000


sol <- c("x1", "x2", "x3")
drift_1 <- c("kappa11 * (mu1 - x1) + kappa12 * (mu2 - x2) + kappa13 * (mu3 - x3)",
                    "kappa21 * (mu1 - x1) + kappa22 * (mu2 - x2) + kappa23 * (mu3 - x3)",
                    "kappa31 * (mu1 - x1) + kappa32 * (mu2 - x2) + kappa33 * (mu3 - x3)")

diff <- matrix(c("sigma11","rho12", "rho13","rho21", "sigma22", "rho23","rho31", "rho32", "sigma33"), 3, 3)


#sampling (delta t)
samp <- setSampling(Terminal = 1, n = 365)

#model
model_z <- setModel(drift = drift_1, diffusion = diff, solve.variable = sol, state.variable = sol)


#yuima object 
my_yuima <- setYuima(data = setData(Z), model = model_z)


param.init <- list(sigma11 = sd(Z[,1]), sigma22 = sd(Z[,2]), sigma33= sd(Z[,3]), rho12 = 1,  rho23= -1, rho13= -1,
                   rho21 = 1, rho31 = -1, rho32 = -1,
                   mu1 = mean(Z[,1]), mu2 = mean(Z[,2]), mu3= mean(Z[,3]),
                   kappa11 = 0.01, kappa22  = 0.01, kappa33 = 0.01,
                   kappa12 = 0.01, kappa13 = 0.01, kappa21 = 0.01, kappa31 = 0.01, kappa23 = 0.01, kappa32 = 0.01) 

low.par <- list(sigma11 = -2, sigma22 = -2, sigma33= -2, rho12 = -2,  rho23= -2, rho13= -2,
                   rho21 = -2, rho31 = -2, rho32 = -2,
                   mu1 = -2, mu2 = -2, mu3= -2,
                   kappa11 = 0, kappa22  = 0, kappa33 = 0,
                   kappa12 = 0, kappa13 = 0, kappa21 = 0, kappa31 = 0, kappa23 = 0, kappa32 = 0) 

upp.par <- list(sigma11 = 2, sigma22 = 2, sigma33= 2, rho12 = 2,  rho23= 2, rho13= 2,
                rho21 = 2, rho31 = 2, rho32 = 2,
                mu1 = 2, mu2 = 2, mu3= 2,
                kappa11 = 2, kappa22  = 2, kappa33 = 2,
                kappa12 = 2, kappa13 = 2, kappa21 = 2, kappa31 = 2, kappa23 = 2, kappa32 = 2) 

mle1 <- yuima::qmle(my_yuima, start = param.init, lower = low.par, upper = upp.par,
                    method = "L-BFGS-B", 
                    print = TRUE)


coeff_sigma_2 <- coef(mle1)
sigma11 <- coeff_sigma_2["sigma11"]
sigma22 <- coeff_sigma_2["sigma22"]
rho12 <- coeff_sigma_2["rho12"]
rho13 = coeff_sigma_2["rho13"]
rho23 = coeff_sigma_2["rho23"]
sigma33 = coeff_sigma_2["sigma33"]
kappa11 = coeff_sigma_2["kappa11"]
kappa22 = coeff_sigma_2["kappa22"]
kappa33 = coeff_sigma_2["kappa33"]
kappa12 = coeff_sigma_2["kappa12"]
kappa21 = coeff_sigma_2["kappa21"]
kappa13 = coeff_sigma_2["kappa13"]
kappa31 = coeff_sigma_2["kappa31"]
kappa23 = coeff_sigma_2["kappa23"]
kappa32 = coeff_sigma_2["kappa32"]
mu1 = coeff_sigma_2["mu1"]
mu2 = coeff_sigma_2["mu2"]
mu3 = coeff_sigma_2["mu3"]
rho31 = coeff_sigma_2["rho31"]
rho21 = coeff_sigma_2["rho21"]
rho32 = coeff_sigma_2["rho32"]



set.seed(385)

simulations <- vector("list", n_simulations)


for (i in 1:n_simulations) {
  simu <- simulate(model_z, sampling = samp, xinit = Z[nrow(Z),], true.parameter = list(kappa11 = kappa11, kappa22 = kappa22, mu1 = mu1, mu2 = mu2,
                                                                                        kappa33 = kappa33, mu3= mu3, rho13= rho13, rho23 = rho23, sigma33 = sigma33,
                                                                                        sigma11=sigma11, rho12=rho12, sigma22 = sigma22, rho21 = rho21, rho31 = rho31,
                                                                                        rho32 = rho32, kappa12 = kappa12, kappa21 = kappa21, kappa31 = kappa31, kappa13 = kappa13, 
                                                                                        kappa23 = kappa23, kappa32 = kappa32))
  simulations[[i]] <- simu@data@original.data
}



# Convert list to a matrix
sim_matrix_list <- lapply(1:3, function(i) sapply(simulations, function(sim) sim[, i]))
sim_z1 <- sim_matrix_list[[1]]
sim_z2 <- sim_matrix_list[[2]]
sim_z3 <- sim_matrix_list[[3]]


# Compute the average path
average_paths <- sapply(sim_matrix_list, rowMeans)
time <- index(simu@data@original.data)  # time index

# Combine the average paths into a single matrix
average_path_all <- do.call(cbind, lapply(1:3, function(i) average_paths[, i]))

# Compute the average path
average_path_1 <- average_path_all[,1]
average_path_2 <- average_path_all[,2]
average_path_3 <- average_path_all[,3]
correlation_matrix <- cor(average_path_all)

# Create the plot without adjusting the z3 axis
fig <- plot_ly() %>%
  add_lines(x = ~time, y = ~average_path_1, name = 'z1', line = list(color = '#1f77b4', width = 2)) %>%
  add_lines(x = ~time, y = ~average_path_2, name = 'z2', line = list(color = '#ff7f0e', width = 2)) %>%
  add_lines(x = ~time, y = ~average_path_3, name = 'z3', yaxis = 'y2', line = list(color = '#2ca02c', width = 2)) %>%
  layout(
    xaxis = list(title = 'Time'),
    yaxis = list(title = 'Z1 and Z2 values', range = c(min(average_path_1) - 0.01, max(average_path_2) + 0.01)),
    yaxis2 = list(
      title = 'Z3 value',
      overlaying = 'y',
      side = 'right'
    ),
    legend = list(x = 1.05, y = 1),
    grid = list(color = 'gray')
  )

# Display the plot
fig



#Plot all the paths
df_simu <- as.data.frame(sim_z1)
df_simu$Time <- time

# Melt the data frame to long format
df_long <- melt(df_simu, id.vars = "Time", variable.name = "Path", value.name = "Value")

# Plot all paths
ggplot(df_long, aes(x = Time, y = Value, group = Path)) +
  geom_line(alpha = 0.1, linewidth = 0.5, color = "blue") +
  labs(x = "Time", y = "Z") +
  theme_bw() +  # Use theme_bw for a similar style
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.5),
    panel.grid.major = element_line(color = "grey80"),
    panel.grid.minor = element_line(color = "grey90")
  )
