# packages
require(reticulate)
require(yuima)
require(rstudioapi)

# wd and load  ----

setwd(dirname(getActiveDocumentContext()$path))

# import module
np <- import("numpy")

Z <- np$load("z_vector_4d_19_22.npy") 

n_simulations <- 1000



sol <- c("x1", "x2", "x3", "x4")


drift_1 <- matrix(c("kappa11 * (mu1 - x1)", "kappa12 * (mu1 - x2)", "kappa13 * (mu1 - x3)", "kappa14 * (mu1 - x4)",
                    "kappa21 * (mu2 - x1)", "kappa22 * (mu2 - x2)", "kappa23 * (mu2 - x3)", "kappa24 * (mu2 - x4)",
                    "kappa31 * (mu3 - x1)", "kappa32 * (mu3 - x2)", "kappa33 * (mu3 - x3)", "kappa34 * (mu3 - x4)",
                    "kappa41 * (mu4 - x1)", "kappa42 * (mu4 - x2)", "kappa43 * (mu4 - x3)", "kappa44 * (mu4 - x4)"),4,4)


diff <- matrix(c( "sigma11", "rho12", "rho13", "rho14", "rho21",
                  "sigma22", "rho23", "rho24", "rho31", "rho32",
                  "sigma33", "rho34", "rho41", "rho42", "rho43", "sigma44"
), 4, 4)

# sampling (delta t)
samp <- setSampling(Terminal = 1, n = 365)

# model
model_z <- setModel(drift = drift_1, diffusion = diff, solve.variable = sol, state.variable = sol)

# yuima object 
my_yuima <- setYuima(data = setData(Z), model = model_z)


param.init <- list(
  kappa11 = 0, mu1 = mean(Z[,1]),
  kappa22 = 0, mu2 = mean(Z[,2]),
  kappa33 = 0, mu3 = mean(Z[,3]),
  kappa44 = 0, mu4 = mean(Z[,4]),
  sigma11 = sd(Z[,1]), rho12 = 0.1, rho13 = 0.1, rho14 = 0.1,
  sigma22 = sd(Z[,2]), rho21 = 0.1, rho23 = 0.1, rho24 = 0.1, 
  sigma33 = sd(Z[,3]), rho31 = 0.1, rho32 = 0.1, rho34 = 0.1,
  sigma44 = sd(Z[,4]), rho41 = 0.1, rho42 = 0.1, rho43 = 0.1,
  kappa12 = 0,  kappa13 = 0,  kappa14 = 0,  kappa21 = 0,  kappa23 = 0,
  kappa24 = 0,  kappa31 = 0,  kappa32 = 0,  kappa34 = 0,  kappa41 = 0,
  kappa42 = 0, kappa43 = 0
  
)

# Adjust the bounds to be more realistic
low.par <- list(
  kappa11 = -10, mu1 = -10,
  kappa22 = -10, mu2 = -10,
  kappa33 = -10, mu3 = -10,
  kappa44 = -10, mu4 = -10,
  sigma11 = -10, rho12 = -10, rho13 = -10, rho14 = -10,
  sigma22 = -10, rho21 = -10, rho23 = -10, rho24 = -10, 
  sigma33 = -10, rho31 = -10, rho32 = -10, rho34 = -10,
  sigma44 = -10, rho41 = -10, rho42 = -10, rho43 = -10,
  kappa12 = -10,  kappa13 = -10,  kappa14 = -10,  kappa21 = -10,  kappa23 = -10,
  kappa24 = -10,  kappa31 = -10,  kappa32 = -10,  kappa34 = -10,  kappa41 = -10,
  kappa42 = -10, kappa43 = -10
)

upp.par <- list(
  kappa11 = 10, mu1 = 10,
  kappa22 = 10, mu2 = 10,
  kappa33 = 10, mu3 = 10,
  kappa44 = 10, mu4 = 10,
  sigma11 = 10, rho12 = 10, rho13 = 10, rho14 = 10,
  sigma22 = 10, rho21 = 10, rho23 = 10, rho24 = 10, 
  sigma33 = 10, rho31 = 10, rho32 = 10, rho34 = 10,
  sigma44 = 10, rho41 = 10, rho42 = 10, rho43 = 10, 
  kappa12 = 10,  kappa13 = 10,  kappa14 = 10,  kappa21 = 10,  kappa23 = 10,
  kappa24 = 10,  kappa31 = 10,  kappa32 = 10,  kappa34 = 10,  kappa41 = 10,
  kappa42 = 10, kappa43 = 10
)

mle1 <- yuima::qmle(my_yuima, start = param.init, lower = low.par, upper = upp.par,
                    method = "L-BFGS-B", 
                    print = TRUE)

coeff_sigma_5 <- coef(mle1)
sigma11 <- coeff_sigma_5["sigma11"]
rho12 <- coeff_sigma_5["rho12"]
rho13 <- coeff_sigma_5["rho13"]
rho14 <- coeff_sigma_5["rho14"]
sigma22 <- coeff_sigma_5["sigma22"]
rho23 <- coeff_sigma_5["rho23"]
rho24 <- coeff_sigma_5["rho24"]
sigma33 <- coeff_sigma_5["sigma33"]
rho34 <- coeff_sigma_5["rho34"]
sigma44 <- coeff_sigma_5["sigma44"]
kappa1 <- coeff_sigma_5["kappa1"]
kappa2 <- coeff_sigma_5["kappa2"]
kappa3 <- coeff_sigma_5["kappa3"]
kappa4 <- coeff_sigma_5["kappa4"]
mu1 <- coeff_sigma_5["mu1"]
mu2 <- coeff_sigma_5["mu2"]
mu3 <- coeff_sigma_5["mu3"]
mu4 <- coeff_sigma_5["mu4"]


set.seed(50)

simulations <- vector("list", n_simulations)

for (i in 1:n_simulations) {
  simu <- simulate(model_z, sampling = samp, xinit = Z[nrow(Z), ], 
                   true.parameter = list(
                     sigma11 = sigma11, rho12 = rho12, rho13 = rho13, rho14 = rho14,
                     sigma22 = sigma22, rho23 = rho23, rho24 = rho24,
                     sigma33 = sigma33, rho34 = rho34,
                     sigma44 = sigma44,
                     kappa1 = kappa1, mu1 = mu1,
                     kappa2 = kappa2, mu2 = mu2,
                     kappa3 = kappa3, mu3 = mu3,
                     kappa4 = kappa4, mu4 = mu4
                   ))
  simulations[[i]] <- simu@data@original.data
}

# Convert list to a matrix
sim_matrix_list <- lapply(1:4, function(i) sapply(simulations, function(sim) sim[, i]))

# Compute the average path
average_paths <- sapply(sim_matrix_list, rowMeans)
time <- index(simu@data@original.data)  # time index

# Combine the average paths into a single matrix
average_path_all <- do.call(cbind, lapply(1:4, function(i) average_paths[, i]))

# Plot the average paths (example for first dimension)
plot(time, average_path_all[, 1], type = "l", col = "blue", xlab = "Time", ylab = "Average X_t", main = "Average of 100000 Simulated Paths")

